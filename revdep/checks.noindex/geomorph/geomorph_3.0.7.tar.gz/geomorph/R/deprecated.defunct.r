#' Deprecated functions in geomorph
#'
#' The following function has been deprecated in geomorph
#'
#' This function has been deprecated. Below shows the original function and the replacement function.
#' 
#' @export
