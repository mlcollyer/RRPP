#' Deprecated and defunct functions in geomorph
#'
#' The following function is now defunct
#'
#' 
